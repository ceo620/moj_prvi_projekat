from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict

def load_json(path: str | Path) -> Dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as f:
        return json.load(f)

def build_sources_uses_bridge(ass: Dict[str, Any]) -> Dict[str, Any]:
    uses = {
        "Direct_CAPEX_EUR": float(ass["direct_capex_eur"]),
        "Contingency_EUR": float(ass["contingency_eur"]),
        "Other_Project_Costs_EUR": float(ass["other_project_costs_eur"]),
    }
    uses_total = sum(uses.values())
    sources = {
        "Senior_Debt_EUR": float(ass["debt_amount_eur"]),
        "Equity_EUR": float(ass["equity_amount_eur"]),
    }
    sources_total = sum(sources.values())
    return {
        "Uses": uses,
        "Uses_Total_EUR": round(uses_total, 2),
        "Sources": sources,
        "Sources_Total_EUR": round(sources_total, 2),
        "Checks": {
            "Uses_equals_TPC": round(uses_total, 2) == round(float(ass["tpc_eur"]), 2),
            "Sources_equals_TPC": round(sources_total, 2) == round(float(ass["tpc_eur"]), 2),
            "Sources_minus_Uses_EUR": round(sources_total - uses_total, 2),
        },
    }
