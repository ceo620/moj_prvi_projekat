#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def normalize_record(row: dict) -> dict:
    prompt = row.get("prompt_grok") or row.get("prompt_text") or ""
    negative_prompt = row.get("negative_prompt") or ""
    code = row.get("variant_id") or row.get("prompt_id") or row.get("code") or "UNKNOWN"

    return {
        "code": code,
        "scenario": row.get("scenario") or row.get("category") or "unknown",
        "category": row.get("category", "unknown"),
        "mutation_style": row.get("mutation_style", ""),
        "wardrobe": row.get("wardrobe", ""),
        "environment": row.get("environment", ""),
        "expression": row.get("expression", ""),
        "shot_type": row.get("shot_type", ""),
        "accessory": row.get("accessory", ""),
        "lighting": row.get("lighting", ""),
        "camera": row.get("camera", ""),
        "risk_score": row.get("risk_score", ""),
        "risk_driver": row.get("risk_driver", ""),
        "rationale": row.get("rationale", ""),
        "prompt_grok": prompt,
        "negative_prompt": negative_prompt,
    }


def export_central_brain(input_json: Path, output_dir: Path) -> None:
    data = load_json(input_json)
    if not isinstance(data, list):
        raise ValueError("Input must be a JSON list of prompt records.")

    records = [normalize_record(x) for x in data]
    code_map = {r["code"]: r for r in records}
    lookup = {
        "version": "central_brain_v1",
        "record_count": len(records),
        "lookup_mode": "exact_code_match",
        "records": records,
        "code_index": code_map,
    }

    output_dir.mkdir(parents=True, exist_ok=True)
    write_json(output_dir / "grok_central_brain_lookup.json", lookup)

    with (output_dir / "grok_central_brain_lookup.csv").open("w", newline="", encoding="utf-8") as f:
        fieldnames = list(records[0].keys()) if records else [
            "code","scenario","category","mutation_style","wardrobe","environment","expression","shot_type",
            "accessory","lighting","camera","risk_score","risk_driver","rationale","prompt_grok","negative_prompt"
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)

    instruction_text = f"""GROK CENTRAL BRAIN — PHOTO CODE EXTRACTION SYSTEM

ROLE
You are the photo-code retrieval brain for an avatar prompt system.

PRIMARY RULE
When the user gives a code like MUT_021 or MUT_047, search the uploaded central brain file and return the EXACT matching record.

OUTPUT FORMAT
Return:

CODE:
SCENARIO:
CATEGORY:
MUTATION_STYLE:
WARDROBE:
ENVIRONMENT:
EXPRESSION:
SHOT_TYPE:
ACCESSORY:
LIGHTING:
CAMERA:
RISK_SCORE:
RISK_DRIVER:
RATIONALE:
PROMPT_GROK:
NEGATIVE_PROMPT:

STRICT RULES
1. Do not summarize unless user asks.
2. Do not rewrite fields unless user asks.
3. Always return exact stored values for the matching code.
4. If multiple near matches exist, prefer exact code match only.
5. If code is not found, say: CODE NOT FOUND.
6. If user says "full extract MUT_021", return all fields.
7. If user says "prompt only MUT_021", return only PROMPT_GROK and NEGATIVE_PROMPT.
8. If user says "compare MUT_021 vs MUT_047", return both full records in the same format.
9. If user says "safe only", prioritize records with risk_score <= 3.
10. Never invent fields that do not exist in the central brain file.

SEARCH TARGET
Use the uploaded file:
- grok_central_brain_lookup.json

This file contains {len(records)} indexed records.
"""
    (output_dir / "GROK_CENTRAL_BRAIN_INSTRUCTIONS.txt").write_text(instruction_text, encoding="utf-8")


def lookup_code(lookup_json: Path, code: str) -> None:
    data = load_json(lookup_json)
    code_index = data.get("code_index", {})
    result = code_index.get(code)
    if result is None:
        print("CODE NOT FOUND")
        return
    print(json.dumps(result, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description="Grok Central Brain Exporter")
    sub = parser.add_subparsers(dest="command", required=True)

    p_export = sub.add_parser("export-central-brain")
    p_export.add_argument("--input-json", required=True)
    p_export.add_argument("--output-dir", required=True)

    p_lookup = sub.add_parser("lookup-code")
    p_lookup.add_argument("--lookup-json", required=True)
    p_lookup.add_argument("--code", required=True)

    args = parser.parse_args()

    if args.command == "export-central-brain":
        export_central_brain(Path(args.input_json), Path(args.output_dir))
    elif args.command == "lookup-code":
        lookup_code(Path(args.lookup_json), args.code)


if __name__ == "__main__":
    main()
