#!/usr/bin/env python3
# ============================================================
# TITAN iPhone Broad Analyzer (Documents + Images + Notes)
# STATUS: SYSTEM RED — STEP102 LOCKED — NO FINAL USE
# ============================================================

import argparse
import hashlib
from datetime import datetime
from pathlib import Path

try:
    import openpyxl
except ImportError:
    openpyxl = None

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def get_category(ext):
    ext = ext.lower()
    if ext in {".jpg", ".jpeg", ".png", ".heic", ".gif", ".webp"}:
        return "Image"
    elif ext in {".pdf", ".docx", ".doc", ".xlsx", ".xls", ".txt", ".md", ".csv"}:
        return "Document"
    elif ext in {".note", ".txt"}:   # Notes app exports
        return "Note"
    else:
        return "Other"

def collect_files(root_path):
    root = Path(root_path)
    if not root.exists():
        return []

    rows = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            try:
                ext = p.suffix.lower()
                rows.append({
                    "Source": "iPhone",
                    "Category": get_category(ext),
                    "File_Name": p.name,
                    "Full_Path": str(p),
                    "Extension": ext,
                    "Size_Bytes": p.stat().st_size,
                    "SHA256": sha256_file(p),
                    "Modified_UTC": datetime.utcfromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds"),
                    "Review_Status": "REVIEW_REQUIRED",
                    "Final_Use_Allowed": "NO"
                })
            except Exception as e:
                print(f"Error: {p} -> {e}")
    return rows

def create_excel(records, out_xlsx):
    if openpyxl is None:
        print("openpyxl nije instaliran")
        return

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "iPhone_Files"

    headers = ["Source", "Category", "File_Name", "Full_Path", "Extension", 
               "Size_Bytes", "SHA256", "Modified_UTC", "Review_Status", "Final_Use_Allowed"]
    ws.append(headers)
    for r in records:
        ws.append([r.get(h, "") for h in headers])

    ws2 = wb.create_sheet("Summary")
    ws2.append(["Metric", "Value"])
    ws2.append(["Generated_At", datetime.now().isoformat()])
    ws2.append(["Total_Files", len(records)])
    ws2.append(["Images", len([r for r in records if r["Category"] == "Image"])])
    ws2.append(["Documents", len([r for r in records if r["Category"] == "Document"])])
    ws2.append(["Notes", len([r for r in records if r["Category"] == "Note"])])
    ws2.append(["Other", len([r for r in records if r["Category"] == "Other"])])
    ws2.append(["SYSTEM_STATUS", "SYSTEM RED"])
    ws2.append(["STEP102", "LOCKED / NOT ACCEPTED"])

    Path(out_xlsx).parent.mkdir(parents=True, exist_ok=True)
    wb.save(out_xlsx)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", required=True)
    p.add_argument("--out-xlsx", required=True)
    args = p.parse_args()

    print(f"🔍 Skeniram: {args.root}")
    recs = collect_files(args.root)
    print(f"✅ Pronađeno fajlova: {len(recs)}")

    create_excel(recs, args.out_xlsx)
    print(f"✅ Excel kreiran: {args.out_xlsx}")
    print("SYSTEM RED — STEP102 LOCKED — NO FINAL USE")

if __name__ == "__main__":
    main()
