import json, os
from datetime import datetime
from docx import Document
from docx.shared import Pt

with open("00_MASTER_TOKEN_AUTHORITY/MASTER_TOKEN_REGISTER.json") as f:
    master = json.load(f)

print("🔒 CTOS — Controlled Generation (SIGNALNI_MEMORANDUM_TITAN1)")

doc = Document()
doc.styles['Normal'].font.name = 'Calibri'
doc.styles['Normal'].font.size = Pt(11)

doc.add_heading('SIGNALNI MEMORANDUM', 0).alignment = 1
doc.add_heading('TITAN 1 – Institucionalna koordinacija i proceduralno usmjeravanje', 1).alignment = 1
doc.add_paragraph(f'Datum: 2026-05-10\n')

text = f"""Poštovani,

Ovaj memorandum se odnosi isključivo na projekat **TITAN 1** – Fabrika transformatorskih kazana (tankova).

Nosilac projekta:  
{master['canonical_company']}

Lokacija:  
{master['canonical_location']}, Crna Gora

Projekat TITAN 1 predviđa investiciju od približno {master['canonical_capex_label']} i ima za cilj jačanje metaloprerađivačke industrije, otvaranje novih radnih mjesta te doprinos energetskom lancu i industrijskoj tranziciji u Crnoj Gori.

U cilju dalje institucionalne koordinacije molimo za:
• informaciju o raspoloživom kapacitetu i statusu elektrodistributivne infrastrukture,
• proceduru i tehničke uslove priključenja,
• mogućnosti institucionalnog usmjeravanja i podrške u okviru važećih propisa.

Molimo Vas da ovaj memorandum razmotrite kao signal za dalju saradnju i proceduralno usklađivanje.

Sa poštovanjem,

DANIJELA KESKIN  
Director  
Ars Metal Industries D.O.O. Podgorica"""

for paragraph in text.split('\n'):
    if paragraph.strip():
        p = doc.add_paragraph(paragraph)

filename = "SIGNALNI_MEMORANDUM_TITAN1_2026-05-10.docx"
doc.save(filename)

print(f"\n✅ SIGNALNI_MEMORANDUM_TITAN1 generisan: {filename}")
print("   Generisan isključivo iz MASTER_TOKEN_REGISTER + DOCUMENT_SCOPE_POLICY")
print("   Spreman za manual review i human signoff.")
