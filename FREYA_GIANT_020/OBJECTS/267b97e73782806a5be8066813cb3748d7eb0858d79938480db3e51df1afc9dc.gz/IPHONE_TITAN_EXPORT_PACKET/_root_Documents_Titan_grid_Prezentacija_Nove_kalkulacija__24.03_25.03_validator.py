from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict, List

REQUIRED_KEYS = [
    "tpc_eur","direct_capex_eur","contingency_eur","other_project_costs_eur",
    "debt_pct","equity_pct","debt_amount_eur","equity_amount_eur","idc_eur",
    "revenue_y1_eur","revenue_y5_eur","revenue_y12_eur","ebitda_margin_steady_state",
    "cash_conversion_cycle_days","nwc_y5_eur","nwc_pct_of_revenue","min_dscr",
    "avg_dscr","dsra_months","baseline_version","baseline_status"
]

def load_json(path: str | Path) -> Dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as f:
        return json.load(f)

def validate_master_assumptions_v45(ass: Dict[str, Any]) -> Dict[str, Any]:
    issues: List[str] = []
    warnings: List[str] = []
    checks: Dict[str, Any] = {}

    for key in REQUIRED_KEYS:
        if key not in ass:
            issues.append(f"Missing required key: {key}")
    if issues:
        return {"valid": False, "issues": issues, "warnings": warnings, "checks": checks}

    if round(float(ass["debt_pct"]) + float(ass["equity_pct"]), 6) != 1.0:
        issues.append("Debt % + Equity % must equal 1.00")

    calc_debt = round(float(ass["tpc_eur"]) * float(ass["debt_pct"]))
    calc_equity = round(float(ass["tpc_eur"]) * float(ass["equity_pct"]))
    checks["calc_debt_eur"] = calc_debt
    checks["calc_equity_eur"] = calc_equity

    if calc_debt != int(ass["debt_amount_eur"]):
        warnings.append(f"Debt amount mismatch: expected {calc_debt}, got {ass['debt_amount_eur']}")
    if calc_equity != int(ass["equity_amount_eur"]):
        warnings.append(f"Equity amount mismatch: expected {calc_equity}, got {ass['equity_amount_eur']}")

    uses_total = float(ass["direct_capex_eur"]) + float(ass["contingency_eur"]) + float(ass["other_project_costs_eur"])
    checks["uses_total_eur"] = round(uses_total, 2)
    checks["tpc_eur"] = round(float(ass["tpc_eur"]), 2)
    if round(uses_total, 2) != round(float(ass["tpc_eur"]), 2):
        issues.append(f"Uses total {uses_total:,.2f} does not reconcile to TPC {float(ass['tpc_eur']):,.2f}")

    sources_total = float(ass["debt_amount_eur"]) + float(ass["equity_amount_eur"])
    checks["sources_total_eur"] = round(sources_total, 2)
    if round(sources_total, 2) != round(float(ass["tpc_eur"]), 2):
        issues.append(f"Sources total {sources_total:,.2f} does not reconcile to TPC {float(ass['tpc_eur']):,.2f}")

    if round(float(ass["contingency_eur"]), 2) != round(float(ass["direct_capex_eur"]) * float(ass["contingency_pct"]), 2):
        warnings.append("Contingency does not equal Direct CAPEX × contingency_pct")

    if float(ass["revenue_y5_eur"]) < float(ass["revenue_y1_eur"]):
        issues.append("Revenue Y5 cannot be below Revenue Y1")
    if float(ass["revenue_y12_eur"]) < float(ass["revenue_y5_eur"]):
        warnings.append("Revenue Y12 is below Revenue Y5; confirm maturity curve")

    if not 0 <= float(ass["ebitda_margin_steady_state"]) <= 1:
        issues.append("EBITDA margin must be between 0 and 1")

    nwc_pct_check = float(ass["nwc_y5_eur"]) / float(ass["revenue_y5_eur"])
    checks["nwc_pct_from_y5"] = round(nwc_pct_check, 6)
    if abs(nwc_pct_check - float(ass["nwc_pct_of_revenue"])) > 0.002:
        warnings.append("NWC % of revenue is not fully aligned with NWC Y5 / Revenue Y5")

    if float(ass["min_dscr"]) <= 1.0:
        issues.append("Minimum DSCR should be above 1.0")
    if float(ass["avg_dscr"]) < float(ass["min_dscr"]):
        issues.append("Average DSCR cannot be below minimum DSCR")

    return {"valid": len(issues) == 0, "issues": issues, "warnings": warnings, "checks": checks}
