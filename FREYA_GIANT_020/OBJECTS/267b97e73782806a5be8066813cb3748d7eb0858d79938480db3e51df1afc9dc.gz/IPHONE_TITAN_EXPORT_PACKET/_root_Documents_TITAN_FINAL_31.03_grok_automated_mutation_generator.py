
from __future__ import annotations

from dataclasses import dataclass, asdict
from itertools import product
from pathlib import Path
import csv
import json
import random

from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.formatting.rule import CellIsRule
from openpyxl.utils import get_column_letter

OUTPUT_DIR = Path.cwd()
EXPORT_BASENAME = "grok_mutation_generator"

ANCHOR = {
    "identity_core": (
        "Same exact woman across all images, identity locked, preserve exact facial geometry, "
        "same bone structure, same eye shape, same nose shape, same jawline, no variation in facial structure."
    ),
    "consistency_lock": (
        "No beauty filter, no stylization drift, no face reshaping, no glamor retouching, visible natural skin texture."
    ),
    "lighting_lock": "soft studio lighting, even illumination, no harsh shadows, natural skin texture",
    "camera_lock": "ultra-realistic photography, 85mm lens, shallow depth of field, high facial fidelity",
    "negative_prompt": (
        "different person, identity drift, face reshaping, beautification distortion, anime, cartoon, stylized skin, "
        "waxy skin, deformed eyes, asymmetrical face, extreme retouching, altered bone structure, blur"
    ),
    "safe_threshold": 3,
    "candidate_count": 100,
    "random_seed": 77,
}

SAFE_LIBRARY = {
    "control": {
        "wardrobe": [("neutral clothing with no distraction", 0), ("plain dark blazer", 0)],
        "environment": [("plain neutral background", 0), ("clean studio backdrop", 0)],
        "expression": [("neutral expression", 0), ("calm and composed", 0)],
        "shot_type": [("front-facing validation portrait", 0), ("head-and-shoulders portrait", 0), ("left three-quarter validation portrait", 1)],
        "accessory": [("no jewelry", 0), ("minimal jewelry", 1)],
    },
    "business": {
        "wardrobe": [("tailored black blazer with white shirt", 0), ("structured navy business suit", 0), ("charcoal blazer with minimal jewelry", 1), ("dark blazer and light blouse", 0)],
        "environment": [("neutral studio background", 0), ("executive office interior", 1), ("glass-and-steel boardroom", 1), ("clean corporate backdrop", 0)],
        "expression": [("authoritative and composed", 0), ("analytical and confident", 0), ("credible and high-authority", 1)],
        "shot_type": [("head-and-shoulders portrait", 0), ("three-quarter corporate portrait", 1)],
        "accessory": [("no jewelry", 0), ("minimal jewelry", 1)],
    },
    "investor": {
        "wardrobe": [("formal dark blazer and light blouse", 0), ("luxury minimalist business suit", 1), ("structured dark suit", 0)],
        "environment": [("institutional finance setting", 1), ("formal meeting room", 1), ("European investment bank style interior", 1)],
        "expression": [("serious and credible", 0), ("strategic and composed", 0), ("calm and intelligent", 0)],
        "shot_type": [("formal institutional portrait", 0), ("seated boardroom portrait", 1)],
        "accessory": [("no jewelry", 0), ("minimal jewelry", 1)],
    },
}

RISK_LIBRARY = [
    ("dramatic high-contrast lighting", "lighting", 4, "high", "High shadow contrast changes perceived facial geometry."),
    ("soft natural window light", "lighting", 2, "medium", "Usable later, but can shift skin tone and shadow placement."),
    ("strong side-lighting stress test", "lighting", 3, "high", "One-sided shadow often triggers identity reconstruction."),
    ("beauty lighting with facial glow", "lighting", 4, "high", "Beauty rendering can smooth identity-defining features."),
    ("35mm lens", "camera", 4, "high", "Wide perspective distorts facial proportions."),
    ("cinematic editorial look", "style", 3, "high", "Styling language invites non-literal facial reinterpretation."),
    ("outdoor backlit scene", "environment", 4, "high", "Backlight reduces visible feature detail."),
    ("strong head tilt", "pose", 2, "medium", "Pose variance can reduce matching confidence."),
    ("statement jewelry", "accessory", 2, "medium", "Visual clutter can pull attention away from the face."),
    ("warm moody evening light", "lighting", 3, "high", "Warm low-key scenes often add beautification drift."),
]


@dataclass
class Candidate:
    variant_id: str
    category: str
    mutation_style: str
    wardrobe: str
    environment: str
    expression: str
    shot_type: str
    accessory: str
    lighting: str
    camera: str
    optional_risky_mutation: str
    risk_wardrobe: int
    risk_environment: int
    risk_expression: int
    risk_shot_type: int
    risk_accessory: int
    risk_lighting: int
    risk_camera: int
    risk_optional: int
    risk_driver: str
    rationale: str
    prompt_grok: str
    negative_prompt: str


def build_prompt(row: dict) -> str:
    accessory_sentence = "" if row["accessory"] == "no jewelry" else f"Accessories: {row['accessory']}."
    optional_sentence = "" if not row.get("optional_risky_mutation") else f"Mutation test: {row['optional_risky_mutation']}."
    parts = [
        ANCHOR["identity_core"],
        ANCHOR["consistency_lock"],
        f"{row['shot_type']}.",
        f"Wearing {row['wardrobe']}.",
        f"Environment: {row['environment']}.",
        f"Expression: {row['expression']}.",
        accessory_sentence,
        f"Lighting: {row['lighting']}.",
        f"Camera: {row['camera']}.",
        optional_sentence,
        f"Category: {row['category']}.",
    ]
    return " ".join([p for p in parts if p]).strip()


def all_safe_combinations() -> list[dict]:
    combos: list[dict] = []
    for category, specs in SAFE_LIBRARY.items():
        for wardrobe, environment, expression, shot_type, accessory in product(
            specs["wardrobe"],
            specs["environment"],
            specs["expression"],
            specs["shot_type"],
            specs["accessory"],
        ):
            combos.append(
                {
                    "category": category,
                    "wardrobe": wardrobe[0],
                    "risk_wardrobe": wardrobe[1],
                    "environment": environment[0],
                    "risk_environment": environment[1],
                    "expression": expression[0],
                    "risk_expression": expression[1],
                    "shot_type": shot_type[0],
                    "risk_shot_type": shot_type[1],
                    "accessory": accessory[0],
                    "risk_accessory": accessory[1],
                }
            )
    return combos


def generate_candidates() -> list[Candidate]:
    random.seed(ANCHOR["random_seed"])
    combos = all_safe_combinations()

    safe_count = int(ANCHOR["candidate_count"] * 0.80)
    risky_count = ANCHOR["candidate_count"] - safe_count

    safe_base = random.sample(combos, safe_count)
    remaining = [c for c in combos if c not in safe_base]
    risky_base = random.sample(remaining, risky_count)

    candidates: list[Candidate] = []

    for idx, base in enumerate(safe_base, start=1):
        row = base.copy()
        row["lighting"] = ANCHOR["lighting_lock"]
        row["camera"] = ANCHOR["camera_lock"]
        row["optional_risky_mutation"] = ""
        prompt = build_prompt(row)
        candidates.append(
            Candidate(
                variant_id=f"MUT_{idx:03d}",
                category=row["category"],
                mutation_style="safe",
                wardrobe=row["wardrobe"],
                environment=row["environment"],
                expression=row["expression"],
                shot_type=row["shot_type"],
                accessory=row["accessory"],
                lighting=row["lighting"],
                camera=row["camera"],
                optional_risky_mutation="",
                risk_wardrobe=row["risk_wardrobe"],
                risk_environment=row["risk_environment"],
                risk_expression=row["risk_expression"],
                risk_shot_type=row["risk_shot_type"],
                risk_accessory=row["risk_accessory"],
                risk_lighting=0,
                risk_camera=0,
                risk_optional=0,
                risk_driver="none",
                rationale="Safe mutation: only wardrobe, environment, expression, shot, or accessory changed.",
                prompt_grok=prompt,
                negative_prompt=ANCHOR["negative_prompt"],
            )
        )

    for idx, base in enumerate(risky_base, start=safe_count + 1):
        row = base.copy()
        mutation, dimension, points, level, why = random.choice(RISK_LIBRARY)
        row["lighting"] = ANCHOR["lighting_lock"]
        row["camera"] = ANCHOR["camera_lock"]
        row["optional_risky_mutation"] = ""

        risk_lighting = 0
        risk_camera = 0
        risk_optional = 0

        if dimension == "lighting":
            row["lighting"] = mutation
            risk_lighting = points
        elif dimension == "camera":
            row["camera"] = f"ultra-realistic photography, {mutation}, shallow depth of field, high facial fidelity"
            risk_camera = points
        else:
            row["optional_risky_mutation"] = mutation
            risk_optional = points

        prompt = build_prompt(row)
        candidates.append(
            Candidate(
                variant_id=f"MUT_{idx:03d}",
                category=row["category"],
                mutation_style="risky_probe",
                wardrobe=row["wardrobe"],
                environment=row["environment"],
                expression=row["expression"],
                shot_type=row["shot_type"],
                accessory=row["accessory"],
                lighting=row["lighting"],
                camera=row["camera"],
                optional_risky_mutation=row["optional_risky_mutation"],
                risk_wardrobe=row["risk_wardrobe"],
                risk_environment=row["risk_environment"],
                risk_expression=row["risk_expression"],
                risk_shot_type=row["risk_shot_type"],
                risk_accessory=row["risk_accessory"],
                risk_lighting=risk_lighting,
                risk_camera=risk_camera,
                risk_optional=risk_optional,
                risk_driver=dimension,
                rationale=why,
                prompt_grok=prompt,
                negative_prompt=ANCHOR["negative_prompt"],
            )
        )

    return candidates


def export_csv(records: list[dict], path: Path) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0].keys()))
        writer.writeheader()
        writer.writerows(records)


def export_json(records: list[dict], path: Path) -> None:
    with path.open("w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)


def style_sheet(ws, freeze="A2") -> None:
    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)
    wrap = Alignment(wrap_text=True, vertical="top")
    thin_gray = Side(style="thin", color="D9D9D9")
    bottom_border = Border(bottom=thin_gray)

    ws.freeze_panes = freeze
    ws.sheet_view.showGridLines = False

    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = wrap
        cell.border = bottom_border


def write_instructions(ws) -> None:
    ws["A1"] = "Step"
    ws["B1"] = "Action"
    rows = [
        ("1", "Edit the anchor settings in 'Anchor_Config' if needed, then rerun the Python script."),
        ("2", "Use only rows marked SAFE on the 'Safe_Only' sheet for Grok prompt testing."),
        ("3", "Image naming rule: MUT_001_01.jpg, MUT_001_02.jpg, etc."),
        ("4", "Do not change identity, consistency, lighting, or camera blocks until you have proven stability."),
        ("5", "If a candidate is marked RISKY, keep it only as a stress test, not as a production prompt."),
        ("6", "Best workflow: test 5 SAFE prompts -> keep top 2 -> mutate again from the best anchor."),
    ]
    for i, row in enumerate(rows, start=2):
        ws[f"A{i}"], ws[f"B{i}"] = row
    style_sheet(ws)
    ws.column_dimensions["A"].width = 10
    ws.column_dimensions["B"].width = 115
    for r in range(2, 8):
        ws[f"B{r}"].alignment = Alignment(wrap_text=True, vertical="top")


def write_anchor_config(ws) -> None:
    ws["A1"] = "Key"
    ws["B1"] = "Value"
    style_sheet(ws)
    rows = [
        ("identity_core", ANCHOR["identity_core"]),
        ("consistency_lock", ANCHOR["consistency_lock"]),
        ("lighting_lock", ANCHOR["lighting_lock"]),
        ("camera_lock", ANCHOR["camera_lock"]),
        ("negative_prompt", ANCHOR["negative_prompt"]),
        ("candidate_count", ANCHOR["candidate_count"]),
        ("random_seed", ANCHOR["random_seed"]),
        ("safe_threshold", ANCHOR["safe_threshold"]),
    ]
    for i, (k, v) in enumerate(rows, start=2):
        ws[f"A{i}"] = k
        ws[f"B{i}"] = v
        ws[f"B{i}"].alignment = Alignment(wrap_text=True, vertical="top")
    ws["B9"].comment = Comment("Candidates with risk_score <= safe_threshold are copied to the Safe_Only sheet.", "OpenAI")
    ws.column_dimensions["A"].width = 22
    ws.column_dimensions["B"].width = 120


def write_safe_library(ws) -> None:
    headers = ["category", "dimension", "option_text", "risk_points", "notes"]
    ws.append(headers)
    for category, specs in SAFE_LIBRARY.items():
        for dimension, options in specs.items():
            for text, points in options:
                note = "safe core" if points == 0 else "still allowed, but watch for small drift"
                ws.append([category, dimension, text, points, note])
    style_sheet(ws)
    widths = [14, 16, 48, 12, 34]
    for idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width


def write_risk_library(ws) -> None:
    headers = ["mutation_text", "dimension", "risk_points", "risk_band", "why_flagged"]
    ws.append(headers)
    for row in RISK_LIBRARY:
        ws.append(list(row))
    style_sheet(ws)
    widths = [34, 14, 12, 12, 58]
    for idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width


def write_candidates(ws, candidates: list[Candidate]) -> None:
    headers = [
        "variant_id", "category", "mutation_style", "wardrobe", "environment", "expression", "shot_type",
        "accessory", "lighting", "camera", "optional_risky_mutation",
        "risk_wardrobe", "risk_environment", "risk_expression", "risk_shot_type", "risk_accessory",
        "risk_lighting", "risk_camera", "risk_optional", "risk_score", "risk_level", "status",
        "risk_driver", "rationale", "prompt_grok", "negative_prompt", "suggested_filename"
    ]
    ws.append(headers)
    for row_no, cand in enumerate(candidates, start=2):
        row = asdict(cand)
        values = [
            row["variant_id"], row["category"], row["mutation_style"], row["wardrobe"], row["environment"],
            row["expression"], row["shot_type"], row["accessory"], row["lighting"], row["camera"],
            row["optional_risky_mutation"], row["risk_wardrobe"], row["risk_environment"], row["risk_expression"],
            row["risk_shot_type"], row["risk_accessory"], row["risk_lighting"], row["risk_camera"],
            row["risk_optional"], None, None, None, row["risk_driver"], row["rationale"], row["prompt_grok"],
            row["negative_prompt"], None
        ]
        ws.append(values)
        ws[f"T{row_no}"] = f"=SUM(L{row_no}:S{row_no})"
        ws[f"U{row_no}"] = f'=IF(T{row_no}<=1,"LOW",IF(T{row_no}<=3,"MEDIUM","HIGH"))'
        ws[f"V{row_no}"] = f'=IF(T{row_no}<=Anchor_Config!$B$9,"SAFE","RISKY")'
        ws[f"AA{row_no}"] = f'=A{row_no}&"_01.jpg"'
    style_sheet(ws)

    widths = {
        "A": 12, "B": 12, "C": 14, "D": 34, "E": 32, "F": 24, "G": 28, "H": 18, "I": 30, "J": 42, "K": 28,
        "L": 10, "M": 10, "N": 10, "O": 10, "P": 10, "Q": 10, "R": 10, "S": 10, "T": 10, "U": 12, "V": 12,
        "W": 12, "X": 44, "Y": 110, "Z": 84, "AA": 18
    }
    for col, width in widths.items():
        ws.column_dimensions[col].width = width

    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")

    ws.conditional_formatting.add(
        f"V2:V{ws.max_row}",
        CellIsRule(operator="equal", formula=['"SAFE"'], fill=PatternFill("solid", fgColor="E2F0D9")),
    )
    ws.conditional_formatting.add(
        f"V2:V{ws.max_row}",
        CellIsRule(operator="equal", formula=['"RISKY"'], fill=PatternFill("solid", fgColor="FCE4D6")),
    )


def write_safe_only(ws, candidates: list[Candidate]) -> None:
    headers = [
        "variant_id", "category", "mutation_style", "risk_score", "risk_level", "status",
        "wardrobe", "environment", "expression", "shot_type", "accessory", "lighting", "camera",
        "prompt_grok", "negative_prompt", "suggested_filename"
    ]
    ws.append(headers)

    safe_rows = []
    for cand in candidates:
        risk_score = (
            cand.risk_wardrobe + cand.risk_environment + cand.risk_expression + cand.risk_shot_type +
            cand.risk_accessory + cand.risk_lighting + cand.risk_camera + cand.risk_optional
        )
        risk_level = "LOW" if risk_score <= 1 else ("MEDIUM" if risk_score <= 3 else "HIGH")
        status = "SAFE" if risk_score <= ANCHOR["safe_threshold"] else "RISKY"
        if status == "SAFE":
            safe_rows.append([
                cand.variant_id, cand.category, cand.mutation_style, risk_score, risk_level, status,
                cand.wardrobe, cand.environment, cand.expression, cand.shot_type, cand.accessory,
                cand.lighting, cand.camera, cand.prompt_grok, cand.negative_prompt, f"{cand.variant_id}_01.jpg"
            ])

    for row in safe_rows:
        ws.append(row)

    style_sheet(ws)
    widths = {
        "A": 12, "B": 12, "C": 14, "D": 10, "E": 12, "F": 10, "G": 34, "H": 32, "I": 24, "J": 28, "K": 18,
        "L": 30, "M": 42, "N": 110, "O": 84, "P": 18
    }
    for col, width in widths.items():
        ws.column_dimensions[col].width = width
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")


def write_summary(ws, candidates: list[Candidate]) -> None:
    ws["A1"] = "Metric"
    ws["B1"] = "Value"
    style_sheet(ws)
    ws["A2"] = "Total candidates"
    ws["B2"] = len(candidates)
    ws["A3"] = "Safe threshold"
    ws["B3"] = "=Anchor_Config!B9"
    ws["A4"] = "SAFE count"
    ws["B4"] = f'=COUNTIF(Candidates_100!V:V,"SAFE")'
    ws["A5"] = "RISKY count"
    ws["B5"] = f'=COUNTIF(Candidates_100!V:V,"RISKY")'
    ws["A6"] = "Control candidates"
    ws["B6"] = f'=COUNTIF(Candidates_100!B:B,"control")'
    ws["A7"] = "Business candidates"
    ws["B7"] = f'=COUNTIF(Candidates_100!B:B,"business")'
    ws["A8"] = "Investor candidates"
    ws["B8"] = f'=COUNTIF(Candidates_100!B:B,"investor")'
    ws["A9"] = "Recommended start batch"
    ws["B9"] = "Begin with 5 SAFE control prompts, then 5 SAFE business prompts."
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 72


def build_workbook(candidates: list[Candidate], output_dir: Path) -> tuple[Path, Path, Path]:
    wb = Workbook()
    ws = wb.active
    ws.title = "Instructions"
    write_instructions(ws)

    write_anchor_config(wb.create_sheet("Anchor_Config"))
    write_safe_library(wb.create_sheet("Safe_Library"))
    write_risk_library(wb.create_sheet("Risk_Library"))
    write_candidates(wb.create_sheet("Candidates_100"), candidates)
    write_safe_only(wb.create_sheet("Safe_Only"), candidates)
    write_summary(wb.create_sheet("Summary"), candidates)

    workbook_path = output_dir / f"{EXPORT_BASENAME}.xlsx"
    wb.save(workbook_path)

    records = [asdict(c) for c in candidates]
    all_csv = output_dir / f"{EXPORT_BASENAME}_candidates.csv"
    export_csv(records, all_csv)

    safe_records: list[dict] = []
    for c in candidates:
        score = c.risk_wardrobe + c.risk_environment + c.risk_expression + c.risk_shot_type + c.risk_accessory + c.risk_lighting + c.risk_camera + c.risk_optional
        if score <= ANCHOR["safe_threshold"]:
            row = asdict(c)
            row["risk_score"] = score
            safe_records.append(row)

    safe_csv = output_dir / f"{EXPORT_BASENAME}_safe_only.csv"
    export_csv(safe_records, safe_csv)

    safe_json = output_dir / f"{EXPORT_BASENAME}_safe_only.json"
    export_json(safe_records, safe_json)

    return workbook_path, all_csv, safe_csv


def maybe_recalculate_and_render(workbook_path: Path) -> None:
    try:
        from artifact_tool import SpreadsheetArtifact

        artifact = SpreadsheetArtifact.load(str(workbook_path))
        for sheet_name in artifact.sheets():
            artifact.sheet(sheet_name).recalculate()
        artifact.render()
        artifact.export(str(workbook_path), overwrite=True)
    except Exception as exc:
        print(f"Artifact recalc/render skipped: {exc}")


def write_readme(output_dir: Path, safe_csv: Path) -> Path:
    readme = output_dir / f"{EXPORT_BASENAME}_README.txt"
    text = f"""Grok Automated Mutation Generator

Files produced:
- {EXPORT_BASENAME}.xlsx
- {EXPORT_BASENAME}_candidates.csv
- {safe_csv.name}
- {EXPORT_BASENAME}_safe_only.json

What this does:
- generates 100 candidate prompt mutations from one anchor
- flags risky mutations with a risk score
- copies only SAFE rows into the Safe_Only sheet and safe-only exports

How to use:
1. Open the workbook and review Anchor_Config.
2. Start in Safe_Only. Ignore risky rows for production.
3. Copy prompt_grok into Grok.
4. Save images with the suggested filename pattern.
5. If you change the anchor text or thresholds, rerun:
   python grok_automated_mutation_generator.py

Risk logic:
- SAFE if risk_score <= {ANCHOR["safe_threshold"]}
- RISKY otherwise

Recommended sequence:
- 5 SAFE control prompts
- 5 SAFE business prompts
- then investor prompts
"""
    readme.write_text(text, encoding="utf-8")
    return readme


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    candidates = generate_candidates()
    workbook_path, all_csv, safe_csv = build_workbook(candidates, OUTPUT_DIR)
    maybe_recalculate_and_render(workbook_path)
    readme = write_readme(OUTPUT_DIR, safe_csv)

    print(f"Generated {len(candidates)} candidates.")
    print(f"Workbook: {workbook_path}")
    print(f"All CSV : {all_csv}")
    print(f"Safe CSV: {safe_csv}")
    print(f"Readme  : {readme}")


if __name__ == "__main__":
    main()
